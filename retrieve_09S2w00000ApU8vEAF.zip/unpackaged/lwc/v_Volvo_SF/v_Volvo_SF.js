import { LightningElement } from 'lwc';
import isguest from '@salesforce/user/isGuest';
export default class V_Volvo_SF extends LightningElement {

}