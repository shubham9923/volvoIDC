import { LightningElement, track, wire,api } from 'lwc';
import getAllAccomplishment from '@salesforce/apex/V_AccomplishmentHelper.getAllAccomplishment';
import isguest from '@salesforce/user/isGuest';

export default class Accomplishments extends LightningElement {
    
     isLowerFolks = false;
     uppercaseItemName;

     @track comparatorValue;
     @track columns = [
          { label: 'Name', fieldName: 'Name' },
          { label: 'Id', fieldName: 'Id'},
          { label: 'Img',fieldName: 'V_Image_long__c'},
          { label: 'Designation',fieldName: 'V_Designation__c'},
          { label: 'Flag Check',fieldName: 'V_CheckIfMultipleOnSameLevel__c'}
      ];
     @track accList;

     

     //Method 2
     @wire (getAllAccomplishment) wiredAccounts({data,error}){
          if (data) {
               this.accList = data;
          console.log(data);
          } else if (error) {
          console.log(error);
          }
     }
    
    handleClick(event) {
     this.accList = data.filter(accList => accList.V_Accomplishment_Date__c > 2);
     console.log(this.accList);
      }

}