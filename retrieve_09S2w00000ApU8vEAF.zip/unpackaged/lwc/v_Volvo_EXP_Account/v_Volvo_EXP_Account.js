import { LightningElement, track, wire,api} from 'lwc';
import getAllAccounts from '@salesforce/apex/V_AccountHelper.getAllAccounts';
import isguest from '@salesforce/user/isGuest';

export default class V_Volvo_EXP_Account extends LightningElement { 
     // @track test = [];
     // @track teams = [];

     // @wire (getAllAccounts) wiredAccounts({data,error}){
     //           if (data) {
     //                this.test = data;              
     //           console.log(data);
     //           } else if (error) {
     //           console.log(error);
     //           }
     //      }

     // connectedCallback() {
     //       this.teams = this.build(test,null);
     // }
     // build(teams,pId){
     //      const c = [];
     //      for(const team of teams){
     //           if(team.parentId === pId ){
     //                c.push({
     //                     ...team,
     //                     c: this.build(teams, team.Id),
     //                });
     //           }
     //      }
     //      return c;
     // }
     @api isLowerFolks = false;
     @api isMuchLowerFolks =false;
     @api isMuchMuchLowerFolks =false;
     @api isSameLevel = false;
     @api isSameLevel1 = false;

     @track accountList = [];
     @track accountList2 = [];
     @track accountList3 = [];
     @track accountList4 = [];

     //Method 2
     @wire (getAllAccounts) wiredAccounts({data,error}){
          if (data) {
               this.accountList = data;              
          console.log(data);
          } else if (error) {
          console.log(error);
          }
     }


     handleclick(evt) {
          let array = [];
          this.isLowerFolks = false;
          this.isMuchLowerFolks = false; 
          this.isMuchMuchLowerFolks = false;
          this.accountList2 = array;
          this.accountList3 = array;
          for (const property in this.accountList) {       
               if(this.accountList[property].ParentId === evt.target.value){
                    array.push(this.accountList[property]);
               }        
          }     
          this.accountList2 = array;
          this.isSameLevel1 = false;
          this.isLowerFolks = true;
          console.log(this.accountList2.length);
    }

    handlelowerclick(evt) {
          let array1 = [];
          let array2 = [];
          this.isLowerFolks = false;
          this.isMuchLowerFolks = false;
          this.isMuchMuchLowerFolks = false; 
          this.isSameLevel = false;
          this.accountList2 = array1;
          for (const property in this.accountList) {
               if(this.accountList[property].Id === evt.target.value){
                    array2.push(this.accountList[property]);
               }       
               if(this.accountList[property].ParentId === evt.target.value){
                    array1.push(this.accountList[property]);
               }        
          }
          if(array1.length > 1){
               this.isSameLevel = false;
          }else{
               this.isSameLevel = true;     
          }
          if(array2.length > 1){
               this.isSameLevel1 = false;
          }else{
               this.isSameLevel1 = true;     
          }
          this.accountList2 = array2;
          this.accountList3 = array1;
          this.isLowerFolks = true;
          this.isMuchLowerFolks = true;
    }

     handleMuchlowerclick(evt) {
          let array1 = [];
          let array2 = [];
          this.isLowerFolks = false;
          this.isMuchLowerFolks = false;
          this.isMuchMuchLowerFolks = false; 
          for (const property in this.accountList) {
               if(this.accountList[property].Id === evt.target.value){
                    array2.push(this.accountList[property]);
               }       
               if(this.accountList[property].ParentId === evt.target.value){
                    array1.push(this.accountList[property]);
               }        
          }
          if(array1.length > 1){
               this.isSameLevel2 = false;
          }else{
               this.isSameLevel2 = true;     
          }
          if(array2.length > 1){
               this.isSameLevel = false;
          }else{
               this.isSameLevel = true;     
          }
          this.accountList3 = array2;
          this.accountList4 = array1;
          this.isLowerFolks = true;
          this.isMuchLowerFolks = true;
          this.isMuchMuchLowerFolks = true;
    }
}