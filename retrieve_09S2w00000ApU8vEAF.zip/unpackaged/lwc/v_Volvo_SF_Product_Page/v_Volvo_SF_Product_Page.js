import { LightningElement, track, wire,api } from 'lwc';
import getAllProducts from '@salesforce/apex/V_ProductHelper.getAllProducts';
import isguest from '@salesforce/user/isGuest';
export default class V_Volvo_SF_Product_Page extends LightningElement {
    /*@track columns = [
          { label: 'Name', fieldName: 'Name' }
      ];*/
     @track productList = [];
     @track productList2 = [];

     //Method 2
     @wire (getAllProducts) wiredProducts({data,error}){
          if (data) {
               this.productList = data;
               for(var key in this.productList){
                    this.productList2.push({value:this.productList[key], key:key});
               }
 
          } else if (error) {
          console.log(error);
          }
     }


}